"""Build an offline HTML preview; no external scripts, styles or assets."""
from pathlib import Path
import base64
import re

root = Path(__file__).resolve().parents[1]
site = root / 'site'
parts = []
for file in ['config.js', 'data.js', 'storage.js', 'app.js']:
    code = (site / file).read_text()
    code = re.sub(r'^import .*?;\n', '', code, flags=re.M)
    code = re.sub(r'\bexport\s+(?=(?:const|function|async))', '', code)
    parts.append(code)
script = '\n\n'.join(parts)
logo = 'data:image/png;base64,' + base64.b64encode((site / 'assets/logo.png').read_bytes()).decode()
symbol = 'data:image/svg+xml;base64,' + base64.b64encode((site / 'assets/deepseek.svg').read_bytes()).decode()
script = script.replace('assets/logo.png', logo).replace('assets/deepseek.svg', symbol)
html = (site / 'index.html').read_text()
html = html.replace('<link rel="stylesheet" href="styles.css" />', '<style>' + (site / 'styles.css').read_text() + '</style>')
html = html.replace('href="assets/logo.png"', 'href="' + logo + '"')
html = html.replace('<script type="module" src="app.js"></script>', '<script type="module">' + script + '</script>')
(root / 'Rest-Time.html').write_text(html)
print('Built Rest-Time.html')

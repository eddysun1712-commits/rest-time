"""Extract two graph indices from the supplied camera / wrist window schema.

Scores are already-computed need-rest percentages, NOT invented predictions.
The uploaded fatigue estimator was trained on relative baseline features. Its
weights and the camera implementation were not included. Removing the baseline
does not make that estimator an absolute-feature model: raw PPG inference must
wait for compatible trained weights. PPG feature extraction remains optional.
"""
from datetime import datetime, timezone
from math import isfinite
from typing import Any


def _score(value):
    if value is None:
        return None
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not isfinite(value) or not 0 <= value <= 100:
        raise ValueError('Index must be a number between 0 and 100')
    return float(value)


def _source(result):
    if not isinstance(result, dict) or result.get('valid') is not True:
        return None
    q = result.get('quality_score', result.get('signal_quality'))
    if q is not None and (isinstance(q, bool) or not isinstance(q, (int, float)) or not isfinite(q) or not 0 < q <= 1):
        return None
    return _score(result.get('need_rest_probability_percent', result.get('probability_percent')))


def normalize_record(record: dict[str, Any]) -> dict:
    if not isinstance(record, dict):
        raise ValueError('Each window must be an object')
    sources = record.get('sources') or {}
    camera = record.get('camera_result', sources.get('camera'))
    wrist = record.get('physiology_result', sources.get('physiology'))
    for key in ('session_id', 'window_start_utc', 'window_end_utc'):
        values = [r.get(key) for r in (record, camera, wrist) if isinstance(r, dict) and r.get(key) not in (None, '')]
        if any(v != values[0] for v in values):
            raise ValueError(f'Mismatched {key}')
    raw_time = record.get('timestamp') or record.get('window_end_utc') or (camera or {}).get('window_end_utc') or (wrist or {}).get('window_end_utc')
    if not isinstance(raw_time, str):
        raise ValueError('Use an ISO timestamp with a timezone')
    parsed = datetime.fromisoformat(raw_time.replace('Z', '+00:00'))
    if parsed.tzinfo is None:
        raise ValueError('Use an ISO timestamp with a timezone')
    if 'camera_index' in record or 'wrist_index' in record:
        c, w = _score(record.get('camera_index')), _score(record.get('wrist_index'))
    else:
        c, w = _source(camera), _source(wrist)
        if record.get('module') == 'camera':
            c = _source(record)
        if record.get('module') == 'physiology':
            w = _source(record)
    return {'timestamp': parsed.astimezone(timezone.utc).isoformat(timespec='milliseconds').replace('+00:00', 'Z'), 'camera_index': c, 'wrist_index': w}


def normalize_batch(payload) -> list[dict]:
    rows = payload if isinstance(payload, list) else payload.get('samples', [payload]) if isinstance(payload, dict) else [payload]
    if not isinstance(rows, list) or not 1 <= len(rows) <= 10000:
        raise ValueError('Import between 1 and 10,000 windows')
    return sorted((normalize_record(row) for row in rows), key=lambda row: row['timestamp'])


def extract_ppg_features(ppg, fs=100.0) -> dict:
    """Optional raw-signal → features only. No baseline and no fatigue score."""
    from .ppg import PPGFeatureExtractor, InvalidWindowError
    try:
        hrv = PPGFeatureExtractor(fs=fs).extract(ppg)
        return {'valid': True, 'features': {'hr_bpm': hrv.hr_bpm, 'rmssd_ms': hrv.rmssd_ms}, 'quality_score': hrv.quality, 'need_rest_probability_percent': None, 'status': 'compatible_model_required'}
    except InvalidWindowError as error:
        return {'valid': False, 'features': {}, 'quality_score': 0.0, 'need_rest_probability_percent': None, 'status': 'insufficient_data', 'error_detail': str(error)}

"""Usage: python -m processor input.json > output.json (or stdin)."""
import json
import sys
from .adapter import normalize_batch

try:
    with open(sys.argv[1], encoding='utf-8') if len(sys.argv) > 1 else sys.stdin as source:
        result = {'samples': normalize_batch(json.load(source))}
    print(json.dumps(result, ensure_ascii=False, allow_nan=False))
except (ValueError, TypeError, KeyError, OSError) as error:
    print(str(error), file=sys.stderr)
    raise SystemExit(1)

"""Stateless input → output adapters; no personal baseline or training layer."""
from .adapter import normalize_batch, normalize_record

__all__ = ['normalize_batch', 'normalize_record']

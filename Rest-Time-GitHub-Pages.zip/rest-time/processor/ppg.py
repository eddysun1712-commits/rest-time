from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from scipy.signal import butter, find_peaks, sosfiltfilt


class InvalidWindowError(ValueError):
    """Raised when a PPG window cannot support reliable beat-to-beat HRV."""


@dataclass(frozen=True)
class HRVResult:
    hr_bpm: float
    rmssd_ms: float
    ln_rmssd: float
    quality: float
    ppi_ms: np.ndarray
    calibration_features: np.ndarray


class PPGFeatureExtractor:
    """Convert a five-minute PPG vector into HR and RMSSD.

    The peak detector uses PPG only. ECG is never consulted at inference time.
    """

    def __init__(
        self,
        fs: float = 100.0,
        low_hz: float = 0.5,
        high_hz: float = 5.0,
        min_hr: float = 40.0,
        max_hr: float = 180.0,
        max_artifact_rate: float = 0.05,
        local_deviation: float = 0.20,
        calibrator=None,
    ) -> None:
        if fs < 25:
            raise ValueError("PPG sampling rate must be at least 25 Hz")
        self.fs = float(fs)
        self.low_hz = float(low_hz)
        self.high_hz = float(high_hz)
        self.min_hr = float(min_hr)
        self.max_hr = float(max_hr)
        self.max_artifact_rate = float(max_artifact_rate)
        self.local_deviation = float(local_deviation)
        self.calibrator = calibrator

    def _filter(self, ppg: np.ndarray) -> np.ndarray:
        x = np.asarray(ppg, dtype=float).reshape(-1)
        if x.size < int(60 * self.fs):
            raise InvalidWindowError("window is shorter than 60 seconds")
        if not np.all(np.isfinite(x)):
            raise InvalidWindowError("PPG contains non-finite values")
        if np.std(x) < 1e-8:
            raise InvalidWindowError("PPG is flat")

        sos = butter(
            4,
            [self.low_hz, self.high_hz],
            btype="bandpass",
            fs=self.fs,
            output="sos",
        )
        filtered = sosfiltfilt(sos, x)
        median = np.median(filtered)
        mad = np.median(np.abs(filtered - median))
        if mad < 1e-8:
            raise InvalidWindowError("filtered PPG has no usable pulse amplitude")
        return (filtered - median) / (1.4826 * mad)

    @staticmethod
    def _local_median(values: np.ndarray, i: int, radius: int = 2) -> float:
        lo = max(0, i - radius)
        hi = min(values.size, i + radius + 1)
        neighborhood = np.delete(values[lo:hi], i - lo)
        return float(np.median(neighborhood)) if neighborhood.size else float(values[i])

    def _clean_ppi(self, ppi_ms: np.ndarray) -> tuple[np.ndarray, float]:
        ppi = np.asarray(ppi_ms, dtype=float)
        if ppi.size < 30:
            raise InvalidWindowError("too few pulse intervals")

        lower = 60_000.0 / self.max_hr
        upper = 60_000.0 / self.min_hr
        bad = (ppi < lower) | (ppi > upper)

        for i in range(ppi.size):
            local = self._local_median(ppi, i)
            if local <= 0 or abs(ppi[i] - local) / local > self.local_deviation:
                bad[i] = True

        artifact_rate = float(np.mean(bad))
        if artifact_rate > self.max_artifact_rate:
            raise InvalidWindowError("too many artifact intervals")
        if bad.size > 1 and np.any(bad[:-1] & bad[1:]):
            raise InvalidWindowError("consecutive artifact intervals")

        clean = ppi.copy()
        bad_indices = np.flatnonzero(bad)
        good_indices = np.flatnonzero(~bad)
        if bad_indices.size:
            if good_indices.size < 2:
                raise InvalidWindowError("not enough valid intervals for interpolation")
            clean[bad_indices] = np.interp(bad_indices, good_indices, clean[good_indices])
        return clean, 1.0 - artifact_rate

    @staticmethod
    def time_domain_features(ppi_ms: np.ndarray) -> tuple[float, float, np.ndarray]:
        ppi = np.asarray(ppi_ms, dtype=float)
        diff = np.diff(ppi)
        if diff.size < 2:
            raise InvalidWindowError("too few successive interval differences")

        hr = 60_000.0 / float(np.mean(ppi))
        sdnn = float(np.std(ppi, ddof=1))
        rmssd = float(np.sqrt(np.mean(diff**2)))
        sdsd = float(np.std(diff, ddof=1))
        pnn50 = float(100.0 * np.mean(np.abs(diff) > 50.0))
        if min(sdnn, rmssd, sdsd) <= 0:
            raise InvalidWindowError("degenerate HRV values")

        # Window-length invariant features used by the MAUS ridge calibrator.
        calibration_features = np.array([pnn50, rmssd, sdsd], dtype=float)
        return hr, rmssd, calibration_features

    def extract(self, ppg: np.ndarray) -> HRVResult:
        filtered = self._filter(ppg)
        minimum_distance = max(1, int(self.fs * 60.0 / self.max_hr))
        peaks, _ = find_peaks(
            filtered,
            distance=minimum_distance,
            prominence=0.5,
        )
        if peaks.size < 31:
            raise InvalidWindowError("too few detected pulse peaks")

        # Quadratic sub-sample peak timing reduces sampling quantization error.
        peak_times = peaks.astype(float)
        for j, idx in enumerate(peaks):
            if 0 < idx < filtered.size - 1:
                y0, y1, y2 = filtered[idx - 1 : idx + 2]
                denominator = y0 - 2.0 * y1 + y2
                if abs(denominator) > 1e-12:
                    peak_times[j] += 0.5 * (y0 - y2) / denominator

        raw_ppi_ms = np.diff(peak_times) * 1000.0 / self.fs
        ppi_ms, quality = self._clean_ppi(raw_ppi_ms)
        hr, raw_rmssd, calibration_features = self.time_domain_features(ppi_ms)

        if self.calibrator is None:
            ln_rmssd = float(np.log(raw_rmssd))
        else:
            ln_rmssd = float(self.calibrator.predict(calibration_features.reshape(1, -1))[0])

        return HRVResult(
            hr_bpm=hr,
            rmssd_ms=float(np.exp(ln_rmssd)),
            ln_rmssd=ln_rmssd,
            quality=quality,
            ppi_ms=ppi_ms,
            calibration_features=calibration_features,
        )


# Rest Time

Five screens: Log In, Sign In (account creation), Start Off, Active, and Active Minimal. Uses the supplied RestTime logo and the DeepSeek symbol from [DeepSeek's official repository](https://github.com/deepseek-ai/DeepSeek-LLM/blob/main/images/logo.svg).

## Open the website

Open **Rest-Time.html** for a self-contained local preview. Create a browser-local account using the **Sign In** link, then press the circular logo to start. Browser-local accounts are a prototype, not cloud authentication or a security boundary against someone with access to that browser. Passwords are salted PBKDF2 hashes rather than plaintext. Measurements, chat drafts, language and sound settings are separated by account in IndexedDB.

The site defaults to Chinese in the active workspace. Use the language tool for English. The full and minimal views share one session timer. DeepSeek opens in the logo panel; in minimal mode it moves the clock to the right on desktop. On small screens the clock sits above chat so both remain usable.

The static site in `site/` needs no install step, build tool or external scripts. Hash routes work under any GitHub Pages repository path.

## Publish on GitHub Pages

1. Create a repository named `rest-time` and upload this project's contents, including `.github/workflows/pages.yml`.
2. In repository **Settings → Pages → Build and deployment**, choose **GitHub Actions** as the source.
3. Push to the `main` branch or run **Publish Rest Time** from the Actions tab.
4. The completed action shows the site's actual Pages URL.

Only `site/` is uploaded to the Pages artifact. Server source, runtime databases and test data are not served by the static site. `.nojekyll` is included.

## Current functionality and placeholders

Working: browser-local sign-up/log-in, password visibility, sign-out, welcome button, clocks, two chart views, hover measurements, time ranges, JSON import, Chinese/English, volume toggle, local per-account storage, DeepSeek panel and pending-message storage. Red-dot notification and two-note sound handling are wired for actual server notifications.

Clear not-implemented popups: Forgot Password, Continue with JD, the sample-data demo, and sending chat messages without a DeepSeek provider. No fabricated AI responses or automatically generated sensor scores are shown.

No PPT was included, so Sign In uses a matching card with Name, Username / Email, Password and Confirm Password.

## Two indices: input → output

Both indices are **probability of needing rest, 0–100%**, as exposed by the uploaded source. They are not inverted into a focus score. The x-axis is window end time; the y-axis is percentage. Both axes cannot meaningfully represent the current time, so the requested y-axis wording is interpreted as the current index value.

**Help → View & import data** accepts the original paired schema:

```json
{
  "window_end_utc": "2026-10-01T12:30:00Z",
  "camera_result": {
    "valid": true,
    "need_rest_probability_percent": 25,
    "quality_score": 0.9
  },
  "physiology_result": {
    "valid": true,
    "need_rest_probability_percent": 32,
    "quality_score": 0.9
  }
}
```

It also accepts fused outputs with `sources.camera` and `sources.physiology`, individual source results identified by `module`, an array, or `{ "samples": [...] }`. UTC or a numeric timezone offset is required. Invalid/zero-quality/missing source windows become gaps. Actual zero percentages stay zero. Mismatched source sessions or windows are rejected.

The normalized record is:

```json
{"timestamp":"2026-10-01T12:30:00.000Z","camera_index":25,"wrist_index":32}
```

Run the stateless Python adapter from the project directory:

```sh
python -m processor input.json > output.json
```

The delivered processor discards personal-baseline enrollment, personal-bias fitting, training and evaluation code. `processor/ppg.py` preserves the supplied raw PPG feature extractor; optional `extract_ppg_features()` reports HR and RMSSD without inventing a rest probability. It needs NumPy/SciPy (`requirements-ppg.txt`). The uploaded archive did **not** contain camera inference code or either trained `.joblib` model. Its fatigue model was trained on baseline-relative inputs; removing those inputs would invalidate that model. Raw-sensor → reliable score therefore remains unimplemented until compatible trained model weights and camera code are supplied.

## Personal server (prepared, not hosted)

### Online website, local account storage

The online `site/` frontend is now configured to call **http://127.0.0.1:8000** on the computer opening the website. The website itself remains on GitHub Pages. Each visitor's Python helper stores their accounts and personal data in their own `runtime/rest-time.sqlite3` database.

Start the helper in the project folder, supplying your published site's origin:

```sh
python3 server.py --port 8000 --origin https://YOUR-NAME.github.io
```

Use the origin only, without the `/rest-time/` path. The online login page's **Connect local service** popup shows the command with its actual origin. Return to the online page and sign up/log in. In browsers that ask for local-network access, allow the website to connect. The helper explicitly permits requests from the configured origin through CORS; it still listens only on loopback by default. Keep it running during use.

Current Chrome supports permission-gated connections to local services; other browser behavior is not visually verified here. Reference: [Chrome Local Network Access](https://developer.chrome.com/blog/local-network-access). The frontend annotates these fetch requests as loopback requests. No browser security settings need to be disabled.

`localhost` always means the computer running the visitor's browser. If the goal is to store **everyone's accounts on one computer belonging to you**, that computer needs a reachable HTTPS backend address (for example, through a tunnel), and `site/config.js` must use that address instead. That is a shared server arrangement, rather than per-visitor local storage.

### Run everything on your own computer

Unzip the project, open Terminal in its `rest-time` folder, and run:

```sh
python3 server.py --port 8000
```

Then open **http://127.0.0.1:8000** in your browser. Use Python 3.11 or later; the website and personal database need no pip installation. Windows users can use `py -3 server.py --port 8000` instead.

The local server automatically supplies a connected frontend configuration. No edit to `site/config.js` is needed. Create a new account on this local site: its records are stored in `runtime/rest-time.sqlite3`, rather than the browser-only prototype database. Keep the Terminal process running during use; press Ctrl+C to stop it. The database persists after stopping or restarting. Keep the `runtime` folder when updating the project and do not upload it to GitHub.

The default address listens only on your computer. The future camera/wrist processor can run alongside the server and submit results to `/v1/input`. Local hosting does not supply the missing inference weights or install DeepSeek: those integrations remain placeholders. Once a DeepSeek provider is installed, the Python process can call its online API while keeping the API key locally.

Serving the whole site locally is an alternative; the online-frontend/local-helper setup above is the intended mode for your clarification. Both modes use the same local SQLite database, so accounts work in either view when connected to the same helper.

GitHub Pages only serves static files. `server.py` is an optional separately hosted Python service using SQLite and standard-library HTTP, with salted PBKDF2 passwords, expiring bearer sessions and user-specific samples, messages and profile records. For production, run behind HTTPS and add deployment-level throttling and account-recovery policies before treating it as a public account service.

```sh
python server.py --port 8000
```

Set `REST_TIME_DB` to a durable writable database path. `--origin` or `REST_TIME_ORIGIN` selects the exact allowed Pages origin (for example `https://YOUR-NAME.github.io`). The default online frontend calls the local helper; only change `apiBase` if you later move to a shared HTTPS backend. Browser-only prototype accounts are separate from helper accounts and are not migrated automatically.

| Endpoint | Purpose |
| --- | --- |
| `POST /v1/signup`, `POST /v1/login` | Authenticate and obtain a session token |
| `GET /v1/me` | Load that user's personal records |
| `POST /v1/preferences` | Save language, sound and active-session start |
| `POST /v1/input` | Send analysis outputs to that user's graph series |
| `GET /v1/data/latest` | Read the graph data |
| `POST /v1/chat` | Pass the personal database and new message to the provider |
| `POST /v1/observe` | Pass the personal database and graph series for proactive review |
| `POST /v1/logout` | Revoke the session token |

All data/chat/preferences endpoints require `Authorization: Bearer <token>`; each query is scoped to its authenticated user. Sensor processing should submit outputs through `/v1/input` using an authenticated session or a future dedicated device credential.

`assistant_exchange()` is the explicit, uninstalled DeepSeek provider boundary. It receives the user profile, samples and chat history on every exchange. The future provider must return `{ "reply": "..." or null, "profile": {...} }`. The server validates and persists the updated profile transactionally; a proactive reply becomes a notification. API keys belong on that server. Until the provider is installed, chat/observe return HTTP 501.

The connected frontend fetches data and requests proactive review every 60 seconds while an active session is open. Notifications show a red dot and play the enabled chime. Browser timers can be suspended in background tabs; closed-page or reliable background notifications require a future server scheduler/push implementation.

## Validation

```sh
node tests/data.test.mjs
python -m unittest discover -s tests -p 'test_*.py'
```

Checks cover input ranges, invalid-source gaps, timezone alignment, fused output compatibility, same-window source pairing, authentication failure, account isolation, profile updates and the missing-provider path. Browser visual QA was unavailable in the current environment. Two browser WebMCP tools are feature-detected: read the current session and switch the active/minimal view; unsupported browsers ignore them.

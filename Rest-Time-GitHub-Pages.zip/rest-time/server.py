"""Optional Rest Time backend. Python 3.11+, standard library only.

GitHub Pages serves the online frontend. Run this helper on the visitor's
computer and set --origin to the exact Pages origin; it stores data locally.
The DeepSeek provider intentionally raises NotImplementedError until installed.
"""
import argparse
import hashlib
import hmac
import json
import os
import secrets
import sqlite3
import time
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse

from processor import normalize_batch

ROOT = Path(__file__).resolve().parent
DATABASE = os.environ.get('REST_TIME_DB', str(ROOT / 'runtime' / 'rest-time.sqlite3'))
ORIGIN = os.environ.get('REST_TIME_ORIGIN', '')


def connect():
    conn = sqlite3.connect(DATABASE, timeout=15)
    conn.row_factory = sqlite3.Row
    return conn


def initialize():
    Path(DATABASE).parent.mkdir(parents=True, exist_ok=True)
    with connect() as conn:
        conn.executescript('''
        PRAGMA journal_mode=WAL;
        CREATE TABLE IF NOT EXISTS users(id TEXT PRIMARY KEY, identity TEXT UNIQUE NOT NULL, name TEXT NOT NULL, salt TEXT NOT NULL, password_hash TEXT NOT NULL, profile TEXT NOT NULL DEFAULT '{}', preferences TEXT NOT NULL DEFAULT '{"language":"zh","sound":true}');
        CREATE TABLE IF NOT EXISTS tokens(hash TEXT PRIMARY KEY, user_id TEXT NOT NULL, expires INTEGER NOT NULL);
        CREATE TABLE IF NOT EXISTS samples(user_id TEXT NOT NULL, timestamp TEXT NOT NULL, camera REAL, wrist REAL, PRIMARY KEY(user_id,timestamp));
        CREATE TABLE IF NOT EXISTS messages(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id TEXT NOT NULL,role TEXT NOT NULL,content TEXT NOT NULL,timestamp REAL NOT NULL);
        ''')


def hash_password(password, salt):
    return hashlib.pbkdf2_hmac('sha256', password.encode(), bytes.fromhex(salt), 210000).hex()


def snapshot(conn, user):
    rows = conn.execute('SELECT timestamp,camera,wrist FROM samples WHERE user_id=? ORDER BY timestamp DESC LIMIT 1440', (user['id'],)).fetchall()
    messages = conn.execute('SELECT id,role,content,timestamp FROM messages WHERE user_id=? ORDER BY id DESC LIMIT 200', (user['id'],)).fetchall()
    return {'id': user['id'], 'profile': json.loads(user['profile']), **json.loads(user['preferences']), 'samples': [{'timestamp': r['timestamp'], 'camera_index': r['camera'], 'wrist_index': r['wrist']} for r in reversed(rows)], 'messages': [dict(r) for r in reversed(messages)]}


def assistant_exchange(personal_database, new_message=None, proactive=False):
    """Provider boundary: receives this user's data on EVERY assistant exchange.

    Return {'reply': str|null, 'profile': dict} after schema validation.
    A proactive exchange may return no reply. Keep API keys on the server.
    Do not update personal data until the provider response is validated.
    """
    raise NotImplementedError('DeepSeek API is not connected yet.')


class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(ROOT / 'site'), **kwargs)

    def log_message(self, fmt, *args):
        # No credentials, chat contents or measurement payloads in logs.
        if not self.path.startswith('/v1/'):
            super().log_message(fmt, *args)

    def origin_allowed(self):
        origin = self.headers.get('Origin')
        return not origin or origin == ORIGIN or origin == 'http://' + self.headers.get('Host', '')

    def respond(self, data, status=200):
        content = json.dumps(data, ensure_ascii=False, allow_nan=False).encode()
        self.send_response(status)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(content)))
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        if ORIGIN and self.headers.get('Origin') == ORIGIN:
            self.send_header('Access-Control-Allow-Origin', ORIGIN)
            self.send_header('Vary', 'Origin')
        self.end_headers()
        self.wfile.write(content)

    def do_OPTIONS(self):
        if not self.origin_allowed():
            self.respond({'error': 'Origin not allowed'}, 403)
            return
        self.send_response(204)
        if ORIGIN and self.headers.get('Origin') == ORIGIN:
            self.send_header('Access-Control-Allow-Origin', ORIGIN)
            self.send_header('Vary', 'Origin')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type, Authorization')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        if ORIGIN and self.headers.get('Origin') == ORIGIN and self.headers.get('Access-Control-Request-Private-Network') == 'true':
            # Compatibility with older browsers' private-network preflights.
            self.send_header('Access-Control-Allow-Private-Network', 'true')
        self.end_headers()

    def do_GET(self):
        if urlparse(self.path).path == '/config.js':
            # The local server connects its own frontend automatically, on any
            # port. The copy published on Pages keeps the static prototype config.
            content = b'export const config = Object.freeze({ apiBase: location.origin, refreshMs: 60_000 });\n'
            self.send_response(200)
            self.send_header('Content-Type', 'application/javascript; charset=utf-8')
            self.send_header('Content-Length', str(len(content)))
            self.send_header('Cache-Control', 'no-store')
            self.end_headers()
            self.wfile.write(content)
        elif self.path.startswith('/v1/'):
            self.api('GET')
        else:
            super().do_GET()

    def do_POST(self):
        self.api('POST')

    def api(self, method):
        if not self.origin_allowed():
            self.respond({'error': 'Origin not allowed'}, 403)
            return
        try:
            path = urlparse(self.path).path
            size = int(self.headers.get('Content-Length', '0'))
            if size > 2_000_000 or size < 0:
                self.respond({'error': 'Payload too large'}, 413)
                return
            body = json.loads(self.rfile.read(size)) if size else {}
            if not isinstance(body, (dict, list)):
                raise ValueError('Expected a JSON object or array')
            with connect() as conn:
                if method == 'POST' and path in ('/v1/signup', '/v1/login'):
                    identity = str(body.get('identity', '')).strip().lower()
                    password = body.get('password', '')
                    if not identity or len(identity) > 120 or not isinstance(password, str) or not 8 <= len(password) <= 128:
                        raise ValueError('Provide an identity and a password of 8–128 characters')
                    if path == '/v1/signup':
                        name = str(body.get('name', '')).strip()
                        if not name or len(name) > 120:
                            raise ValueError('Provide a name of 1–120 characters')
                        salt = secrets.token_hex(16)
                        try:
                            conn.execute('INSERT INTO users(id,identity,name,salt,password_hash) VALUES(?,?,?,?,?)', (secrets.token_hex(16), identity, name, salt, hash_password(password, salt)))
                        except sqlite3.IntegrityError:
                            self.respond({'error': 'Account already exists'}, 409)
                            return
                    user = conn.execute('SELECT * FROM users WHERE identity=?', (identity,)).fetchone()
                    if not user or not hmac.compare_digest(hash_password(password, user['salt']), user['password_hash']):
                        self.respond({'error': 'Incorrect username / email or password'}, 401)
                        return
                    token = secrets.token_urlsafe(32)
                    conn.execute('DELETE FROM tokens WHERE expires<?', (time.time(),))
                    conn.execute('INSERT INTO tokens VALUES(?,?,?)', (hashlib.sha256(token.encode()).hexdigest(), user['id'], int(time.time()) + 86400))
                    conn.commit()
                    self.respond({'user': {k: user[k] for k in ('id', 'name', 'identity')}, 'token': token, 'personal': snapshot(conn, user)})
                    return
                authorization = self.headers.get('Authorization', '')
                token_hash = hashlib.sha256(authorization.removeprefix('Bearer ').encode()).hexdigest()
                user = conn.execute('SELECT u.* FROM users u JOIN tokens t ON t.user_id=u.id WHERE t.hash=? AND t.expires>?', (token_hash, time.time())).fetchone() if authorization.startswith('Bearer ') else None
                if not user:
                    self.respond({'error': 'Please log in'}, 401)
                    return
                if method == 'GET' and path == '/v1/me':
                    self.respond({'user': {k: user[k] for k in ('id', 'name', 'identity')}, 'personal': snapshot(conn, user)})
                elif method == 'GET' and path == '/v1/data/latest':
                    self.respond({'samples': snapshot(conn, user)['samples']})
                elif method == 'POST' and path == '/v1/logout':
                    conn.execute('DELETE FROM tokens WHERE hash=?', (token_hash,))
                    conn.commit()
                    self.respond({'ok': True})
                elif method == 'POST' and path == '/v1/preferences':
                    preferences = {'language': body.get('language', 'zh'), 'sound': body.get('sound', True), 'sessionStarted': body.get('sessionStarted')}
                    if preferences['language'] not in ('zh', 'en') or not isinstance(preferences['sound'], bool):
                        raise ValueError('Invalid preferences')
                    start = preferences['sessionStarted']
                    if start is not None and (isinstance(start, bool) or not isinstance(start, (float, int)) or not 0 <= start <= time.time() * 1000):
                        raise ValueError('Invalid session start')
                    conn.execute('UPDATE users SET preferences=? WHERE id=?', (json.dumps(preferences), user['id']))
                    conn.commit()
                    self.respond({'ok': True})
                elif method == 'POST' and path == '/v1/input':
                    samples = normalize_batch(body)
                    for row in samples:
                        conn.execute('INSERT INTO samples VALUES(?,?,?,?) ON CONFLICT(user_id,timestamp) DO UPDATE SET camera=COALESCE(excluded.camera,samples.camera),wrist=COALESCE(excluded.wrist,samples.wrist)', (user['id'], row['timestamp'], row['camera_index'], row['wrist_index']))
                    conn.execute('DELETE FROM samples WHERE user_id=? AND timestamp NOT IN (SELECT timestamp FROM samples WHERE user_id=? ORDER BY timestamp DESC LIMIT 1440)', (user['id'], user['id']))
                    conn.commit()
                    self.respond({'accepted': len(samples)})
                elif method == 'POST' and path in ('/v1/chat', '/v1/observe'):
                    message = str(body.get('message', '')).strip() if path == '/v1/chat' else None
                    if path == '/v1/chat' and (not message or len(message) > 4000):
                        raise ValueError('Provide a message of 1–4000 characters')
                    # Every call passes the personal database, recent readings,
                    # and conversation history to the provider. No shared user state.
                    result = assistant_exchange(snapshot(conn, user), message, proactive=path == '/v1/observe')
                    if not isinstance(result, dict) or not isinstance(result.get('profile'), dict) or result.get('reply') is not None and not isinstance(result['reply'], str):
                        raise ValueError('Invalid assistant result')
                    encoded_profile = json.dumps(result['profile'], allow_nan=False)
                    if len(encoded_profile) > 64000:
                        raise ValueError('Assistant profile is too large')
                    conn.execute('UPDATE users SET profile=? WHERE id=?', (encoded_profile, user['id']))
                    if message:
                        conn.execute('INSERT INTO messages(user_id,role,content,timestamp) VALUES(?,?,?,?)', (user['id'], 'user', message, time.time()))
                    notification = None
                    if result.get('reply'):
                        cur = conn.execute('INSERT INTO messages(user_id,role,content,timestamp) VALUES(?,?,?,?)', (user['id'], 'assistant', result['reply'], time.time()))
                        notification = {'id': str(cur.lastrowid), 'content': result['reply']}
                    conn.commit()
                    self.respond({'profile': result['profile'], 'reply': result.get('reply'), 'notification': notification if path == '/v1/observe' else None})
                else:
                    self.respond({'error': 'Not found'}, 404)
        except NotImplementedError as error:
            self.respond({'error': str(error)}, 501)
        except (ValueError, TypeError, KeyError, AttributeError) as error:
            self.respond({'error': str(error)}, 400)
        except Exception:
            self.respond({'error': 'Server error'}, 500)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--host', default='127.0.0.1')
    parser.add_argument('--port', default=8000, type=int)
    parser.add_argument('--origin', default=ORIGIN, help='Exact allowed online frontend origin, for example https://YOUR-NAME.github.io')
    args = parser.parse_args()
    if args.origin:
        parsed_origin = urlparse(args.origin)
        if parsed_origin.scheme not in ('http', 'https') or not parsed_origin.hostname or parsed_origin.username or parsed_origin.password or parsed_origin.path not in ('', '/') or parsed_origin.query or parsed_origin.fragment:
            parser.error('--origin must be an HTTP(S) origin without a path, credentials or query')
        ORIGIN = args.origin.rstrip('/')
    initialize()
    print(f'Rest Time running at http://{args.host}:{args.port}')
    ThreadingHTTPServer((args.host, args.port), Handler).serve_forever()

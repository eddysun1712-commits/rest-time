"""Meaningful boundary checks; all test data lives in a temporary database."""
import json
import sys
import tempfile
import threading
import unittest
import urllib.error
import urllib.request
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import server


class ServerTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp = tempfile.TemporaryDirectory()
        server.DATABASE = str(Path(cls.temp.name) / 'test.sqlite3')
        server.initialize()
        cls.http = server.ThreadingHTTPServer(('127.0.0.1', 0), server.Handler)
        cls.base = f'http://127.0.0.1:{cls.http.server_port}'
        cls.thread = threading.Thread(target=cls.http.serve_forever, daemon=True)
        cls.thread.start()

    @classmethod
    def tearDownClass(cls):
        cls.http.shutdown(); cls.http.server_close(); cls.temp.cleanup()

    def call(self, path, data=None, token=None):
        headers = {'Content-Type': 'application/json'}
        if token: headers['Authorization'] = 'Bearer ' + token
        req = urllib.request.Request(self.base + path, data=json.dumps(data).encode() if data is not None else None, headers=headers)
        try:
            with urllib.request.urlopen(req) as response: return response.status, json.load(response)
        except urllib.error.HTTPError as response: return response.code, json.load(response)

    def test_accounts_data_and_provider_boundary(self):
        with urllib.request.urlopen(self.base + '/config.js') as response:
            self.assertIn('apiBase: location.origin', response.read().decode())
        status, alice = self.call('/v1/signup', {'name': 'Alice', 'identity': 'alice', 'password': 'correct-horse'})
        self.assertEqual(status, 200)
        _, bob = self.call('/v1/signup', {'name': 'Bob', 'identity': 'bob', 'password': 'other-pass'})
        self.assertEqual(self.call('/v1/login', {'identity': 'alice', 'password': 'wrong-password'})[0], 401)
        self.assertEqual(self.call('/v1/data/latest')[0], 401)
        sample = {'window_end_utc': '2026-10-01T12:00:00Z', 'camera_result': {'valid': True, 'need_rest_probability_percent': 0, 'quality_score': 1}, 'physiology_result': {'valid': True, 'need_rest_probability_percent': 75, 'quality_score': .9}}
        self.assertEqual(self.call('/v1/input', sample, alice['token'])[0], 200)
        _, result = self.call('/v1/data/latest', token=alice['token'])
        self.assertEqual(result['samples'][0]['camera_index'], 0)
        self.assertEqual(result['samples'][0]['wrist_index'], 75)
        self.assertEqual(self.call('/v1/data/latest', token=bob['token'])[1]['samples'], [])
        self.assertEqual(self.call('/v1/input', {'timestamp': '2026-10-01T12:00:00Z', 'camera_index': 101}, alice['token'])[0], 400)
        self.assertEqual(self.call('/v1/preferences', {'language': 'en', 'sound': False}, alice['token'])[0], 200)
        self.assertEqual(self.call('/v1/me', token=alice['token'])[1]['personal']['language'], 'en')
        self.assertEqual(self.call('/v1/chat', {'message': 'Hello'}, alice['token'])[0], 501)
        original = server.assistant_exchange
        def test_provider(personal, new_message=None, proactive=False):
            self.assertEqual(personal['id'], alice['user']['id'])
            self.assertEqual(personal['samples'][0]['wrist_index'], 75)
            if not proactive: self.assertEqual(new_message, 'Hello')
            return {'reply': 'Take a brief break.', 'profile': {'preferred_break_minutes': 5}}
        server.assistant_exchange = test_provider
        try:
            _, result = self.call('/v1/chat', {'message': 'Hello'}, alice['token'])
            self.assertEqual(result['profile']['preferred_break_minutes'], 5)
            _, observed = self.call('/v1/observe', {}, alice['token'])
            self.assertTrue(observed['notification']['id'])
            self.assertEqual(self.call('/v1/me', token=bob['token'])[1]['personal']['profile'], {})
            self.assertEqual(self.call('/v1/me', token=alice['token'])[1]['personal']['profile']['preferred_break_minutes'], 5)
        finally: server.assistant_exchange = original
        self.call('/v1/logout', {}, alice['token'])
        self.assertEqual(self.call('/v1/me', token=alice['token'])[0], 401)

    def test_online_origin_preflight(self):
        previous = server.ORIGIN
        server.ORIGIN = 'https://rest-time.example'
        try:
            req = urllib.request.Request(self.base + '/v1/signup', method='OPTIONS', headers={
                'Origin': server.ORIGIN,
                'Access-Control-Request-Method': 'POST',
                'Access-Control-Request-Headers': 'content-type',
                'Access-Control-Request-Private-Network': 'true',
            })
            with urllib.request.urlopen(req) as response:
                self.assertEqual(response.status, 204)
                self.assertEqual(response.headers['Access-Control-Allow-Origin'], server.ORIGIN)
                self.assertEqual(response.headers['Access-Control-Allow-Private-Network'], 'true')
            req = urllib.request.Request(self.base + '/v1/signup', method='OPTIONS', headers={'Origin':'https://unrelated.example'})
            with self.assertRaises(urllib.error.HTTPError) as error:
                urllib.request.urlopen(req)
            self.assertEqual(error.exception.code, 403)
            self.assertIsNone(error.exception.headers.get('Access-Control-Allow-Origin'))
            req = urllib.request.Request(self.base + '/v1/signup', data=json.dumps({'name':'Online','identity':'online','password':'local-password'}).encode(), headers={'Origin':server.ORIGIN,'Content-Type':'application/json'})
            with urllib.request.urlopen(req) as response:
                self.assertEqual(response.headers['Access-Control-Allow-Origin'], server.ORIGIN)
                self.assertEqual(json.load(response)['user']['identity'], 'online')
        finally:
            server.ORIGIN = previous


if __name__ == '__main__': unittest.main()

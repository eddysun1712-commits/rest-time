import { strict as assert } from 'node:assert';
import { FolderStore } from '../site/folder-store.js';

const missing=()=>Object.assign(new Error('missing'),{name:'NotFoundError'});
class FileHandle {
  constructor(){this.bytes='';this.fail=false;}
  async getFile(){return {size:this.bytes.length,text:async()=>this.bytes};}
  async createWritable(){
    let next='';const file=this;
    return {write:async value=>{next=value;},close:async()=>{if(file.fail)throw new Error('disk full');file.bytes=next;},abort:async()=>{}};
  }
}
class DirectoryHandle {
  constructor(name='chosen-folder',root=null){this.name=name;this.children=new Map();this.files=new Map();this.state='granted';this.root=root??this;}
  async queryPermission(){return this.root.state;}
  async requestPermission(){return this.root.state;}
  async getDirectoryHandle(name,{create=false}={}){if(!this.children.has(name)){if(!create)throw missing();this.children.set(name,new DirectoryHandle(name,this.root));}return this.children.get(name);}
  async getFileHandle(name,{create=false}={}){if(!this.files.has(name)){if(!create)throw missing();this.files.set(name,new FileHandle());}return this.files.get(name);}
}
const root=new DirectoryHandle(),store=new FolderStore(root);
const a={id:'11111111-1111-4111-8111-111111111111',name:'甲',identity:'a',salt:'a'.repeat(32),hash:'b'.repeat(64)};
const b={...a,id:'22222222-2222-4222-8222-222222222222',identity:'b',name:'乙'};
assert.deepEqual(await store.accounts(),[]);
assert.equal(root.children.size,0,'connecting without changes must not create files');
await Promise.all([store.addAccount(a),store.addAccount(b)]);
assert.equal((await store.accounts()).length,2);
await assert.rejects(store.addAccount({...a,id:'33333333-3333-4333-8333-333333333333'}),e=>e.code==='accountExists');
const personal=await store.personal(a.id);
personal.messages.push({role:'user',content:'保存这条消息'});
personal.samples.push({timestamp:'2026-10-01T13:00:00Z',camera_index:0,wrist_index:30});
await store.savePersonal(personal);
const reopened=new FolderStore(root);
assert.deepEqual(await reopened.personal(a.id),personal,'data survives reopening');
assert.equal((await reopened.personal(b.id)).messages.length,0,'account records remain separate');
assert.deepEqual([...root.children.keys()],['rest-time-data'],'only the app subfolder is touched');
const appDirectory=root.children.get('rest-time-data');
assert.deepEqual([...appDirectory.files.keys()].sort(),['accounts.json',a.id+'.json'].sort());
const accountFile=appDirectory.files.get('accounts.json');
assert.equal(accountFile.bytes.includes('password'),false,'no plaintext password field');
const original=accountFile.bytes;
accountFile.bytes='null';
await assert.rejects(reopened.addAccount({...b,identity:'new'}),e=>e.code==='folderCorrupt');
assert.equal(accountFile.bytes,'null','invalid existing content must not be replaced');
accountFile.bytes=original;
root.state='denied';
await assert.rejects(reopened.savePersonal(personal),e=>e.code==='folderPermission');
root.state='granted';
const personalFile=appDirectory.files.get(a.id+'.json'),oldPersonal=personalFile.bytes;
personalFile.fail=true;personal.messages.push({role:'user',content:'未写入'});
await assert.rejects(reopened.savePersonal(personal),e=>e.code==='folderWriteFailed');
assert.equal(personalFile.bytes,oldPersonal,'failed close preserves the previous file');
personalFile.fail=false;
await reopened.savePersonal(personal);
assert.equal((await reopened.personal(a.id)).messages.length,2,'a later write recovers after failure');
await assert.rejects(reopened.personal('../accounts'),e=>e.code==='folderCorrupt');
console.log('Folder storage: scoped files, persistence, isolation, duplicate accounts, permissions, corruption and write recovery passed.');
